# F29SOgroup17 
rcd11 Davidson, Ross 
tf50 Friedenthal, Tegan 
ng47 Ghayyda, Nabil 
cm138 Man, Chloe
mm347 Mohammadi, Musa 
pp2001 Pierzgalski, Patryk 
jat4 Tong, Jack 
Manager: Andrew Ireland 
